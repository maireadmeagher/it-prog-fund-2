public interface INewsFeed {

    void addPost(Post post);
    void deletePost(int index);
    String show();

}
