

public class DVD                                                                                                                                  
{

       private String dvdId;
       private String dvdName;
       private int ageClassification;
       private String category;
       private int numMinutes;
       private static int lenOfTime;
       private int rating;
       
    
    
       // constructor to initialize 
       public DVD(String dvdIdIn, String nIn, String categoryIn, int ageClassificationIn, int numMinutesIn)
       {
          dvdId = dvdIdIn;
          dvdName = nIn;
          category = categoryIn;
          ageClassification = ageClassificationIn;
          numMinutes = numMinutesIn;
          rating = 0;           //rating will be decided later
          lenOfTime = 0;     //lenOfTime will be changed later       
       }
    
       // set dvd id
       public void setDvdId(String dvdIdIn )
       {
          dvdId = dvdIdIn;
       }
    
    
      
       public String getDvdId()
       {
            return dvdId;
       }
       
        
       public void setDvdName(String dvdNameIn)
       {
          dvdName = dvdNameIn;
       }
    
    
          
        public String getDvdName()
          {
             return dvdName ;
    
        }
        
         
        public int getAgeClassification()
        {
             return ageClassification;
    
        }
        
          
        public void setAgeClassification(int ageClassificationIn)
        {
             ageClassification = ageClassificationIn;
    
        }
        
        
         
        public String getCategory()
        {
             return category;
    
        }
        
     
        public void setCategory(String categoryIn)
        {
             category = categoryIn;
    
        }
        
        
        public int getRating()
        {
             return rating;
    
        }
        

        public void setRating(int ratingIn)
        {
             rating = ratingIn;
    
        }
            
        public int getNumMinutes()
        {
             return numMinutes;
    
        }
        

        public void setNumMinutes(int numMinutesIn)
        {
             numMinutes = numMinutesIn;
    
        }        
        
  
        public  static int getLenOfTime()
        {
            return lenOfTime;
        }
 
         public  static void setLenOfTime()
        {
                lenOfTime = lenOfTime + 1;
        }
    
    
} // end class DVD















































//End of program
