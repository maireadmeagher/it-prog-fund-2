public class DvdShop                                                                                                                                                                                                                                                        //Sineads class
{
    // attributes
    private DVD [] dvdList ;   // an array called list to hold all the dvds
    private int total ;          // an interger to hold the number of dvd in the shop

    // methods
    public DvdShop(int sizeIn)            //constructor
    {
        dvdList = new DVD[sizeIn];    //  sets the total number of dvd allow in shop
        total = 0;                      // when we start there are no dvds in shop 
    }

         
    public int getTotal()
    {
        return total;
    }

    public boolean add(DVD dvd1)
    {
        if(isFull() == false)    // if(isFull != true)  // will check if array is full first if not we can add the new dvd 
        {
            dvdList[total] = dvd1;
            total++;
            return true;
        }
        else
        {
            return false;
        }
    }

         
    public boolean remove(String dvdIdIn)
    {
        int index = search(dvdIdIn);    // seraches to find the dvd based on number before deleting

        if(index == -999) // if no such id
        {
            return false; // remove was unsuccessful
        }
        else
        {   // overwrite items by shifting other items along
            for(int i = index; i< total-1; i++)
            {
                dvdList[i] = dvdList[i+1];
            }
            total--; // decrement total number of dvds
            return true; // remove was successful
        }
    }

    public boolean isEmpty()
    {
        if(total==0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean isFull()
    {

        if(total==dvdList.length)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public DVD checkLongestDvd()
    {
        DVD tempDvd = null;

        if(isEmpty() == false)       //checks that array is not empty as if it is there is no need to serach array to find longest dvd 
        {
            tempDvd = dvdList[0];

            for(int i = 1; i < total; i++)
            {
                if(dvdList[i].getNumMinutes() > tempDvd.getNumMinutes())
                {
                    tempDvd = dvdList[i]; 
                }
            }
        }

        return tempDvd;
    }

    public DVD checkShortestDvd()
    {
        DVD tempDvd = null;

        if(isEmpty() == false)
        {
            tempDvd = dvdList[0];

            for(int i = 1; i < total; i++)
            {
                if(dvdList[i].getNumMinutes() < tempDvd.getNumMinutes())
                {
                    tempDvd = dvdList[i]; 
                }      
            }
        }

        return tempDvd;
    }

        
    private int search(String dvdIdIn)
    {
        
          for(int i=0;i<total;i++)
          {
             if(dvdList[i].getDvdId().equals(dvdIdIn) == true)
             {
                return i;
             }
          }
          
        return -999;
    }

       

          
    public String list()
    {
        String list = "";

        if(isEmpty() == false)
        {
            for(int i = 0; i < total; i++)      //goes thorugh arrary and finds all the attributes of each object and adds them to a string to return
            // {
                // list = list + "DVD id: " + dvdList[i].getDvdId() +
                // "\nDVD Name: " + dvdList [i].getDvdName() + 
                // "\nDVD Classification : " + dvdList [i].getAgeClassification() + 
                // "\nDVD Category: " + dvdList[i].getCategory() + 
                // "\nDVD Rating: " + dvdList [i].getRating() + 
                // "\nLength of dvd: " + dvdList [i].getNumMinutes() +
                // "\nNumber of years in shop: " + dvdList [i].getLenOfTime() +

                // "\n\n\n";
            // }
            //Instead, we can use the DVD toString() method. 
            list = list + dvdList[i].toString();
        }

        return list;

    }
          
    public DVD getItem(String dvdId)
    {
        int index;

        index = search(dvdId);

        if(index == -999)
        {
            return null; // indicate invalid index therefore that string is not in the array 
        }
        else
        {
            return dvdList[index];
        }
    }

        
    public static String upDatelenOfTime()
    {

        DVD.setLenOfTime();   //class method so must be called using the class name we send in 1 so everytime it is called we update the attriubute by 1

        return "All information is  updated";
        
    }

    public boolean addDetails(String dvdIdIn, int ratingIn) 
    {

        int index = search(dvdIdIn); //finds dvdNumber

        if(index == -999)
        {
            return false;               //returns false in the dvd id entered does not exist
        }

        else
        {   // sets the extra information

            dvdList[index].setRating(ratingIn);

            return true;               //indicate DVD is there and information has been address

        }
    }

    public String dvdByClassification( int age) 
    {
        String list = "";

        if(isEmpty() == false)
        {

            for(int i = 0; i < total; i++)      //goes thorugh arrary and finds all the attributes of each object and adds them to a string to return
            {
                if(dvdList[i].getAgeClassification() == age)
                {
                    // list = list + "DVD id: " + dvdList[i].getDvdId() +
                    // "\nDVD Name: " + dvdList [i].getDvdName() + 
                    // "\nDVD Classification : " + dvdList [i].getAgeClassification() + 
                    // "\nDVD Category: " + dvdList[i].getCategory() + 
                    // "\nDVD Rating: " + dvdList [i].getRating() + 
                    // "\nLength of dvd: " + dvdList [i].getNumMinutes() +
 

                    // "\n\n";
                    //This can be replaced by : 
                    list = list + dvdList[i].toString();
                }
            }
        }

        return list;
    }

}

