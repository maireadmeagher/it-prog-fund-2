public class XtraVisonApplication
{
    public static void main(String args[])
    {

        int choice;
        int size;
        System.out.print("Enter the maximum number of dvds that can be stored in the shop: ");
        size = EasyScanner.nextInt();

        DvdShop dvdList = new DvdShop(size);
        //  menu options
        do
        {
            System.out.println();
            System.out.println("DVD System");
            System.out.println("1. Add a DVD");
            System.out.println("2. Remove a DVD");
            System.out.println("3. Check if DVD Shop is empty");
            System.out.println("4. Check if DVD Shop is full");
            System.out.println("5. Add Additional DVD Details");
            System.out.println("6. DVD Details");
            System.out.println("7. Update DVD Length of Time in Store ");
            System.out.println("8. Search DVD by Age Classification ");
            System.out.println("9. Exit System");
            System.out.println();

            System.out.print("Please enter choice [1-9 only]: ");
            choice = EasyScanner.nextInt();
            System.out.println();

            // process menu options
            switch(choice)
            {
                case 1: 
                option1(dvdList);    // if 1 is choosen call option1 method and send in dvdList object 
                break;

                case 2: 
                option2(dvdList);    // if 2 is choosen call option1 method and send in dvdList object 
                break;

                case 3: 
                option3(dvdList);    // if 3 is choosen call option1 method and send in dvdList object 
                break;

                case 4: 
                option4(dvdList);    // if 4 is choosen call option1 method and send in dvdList object 
                break;

                case 5: 
                option5(dvdList);     // if 5 is choosen call option1 method and send in dvdList object 
                break;

                case 6: 
                option6(dvdList);    // if 6 is choosen call option1 method and send in dvdList object 
                break;

                case 7: 
                option7(dvdList);     // if 7 is choosen call option1 method and send in dvdList object 
                break;

                case 8: 
                option8(dvdList);
                break;

                case 9: 

                break;

                default : 
                System.out.println("Invalid entry, please enter 1 - 9 only");
                break;
            }

        }
        while(choice!=9);   // continues till option 8 is choosen

        System.out.println("Thank you for using the DVD system");
    }

    // add DVD method
    public static void option1 (DvdShop dvdListIn)
    {
        System.out.print("Enter dvd id: ");
        String id = EasyScanner.nextString();

        System.out.print("Enter DVD name  : ");
        String name = EasyScanner.nextString();

        System.out.print("Enter DVD category  : ");
        String category = EasyScanner.nextString();

        System.out.print("Enter DVD age classification  : ");
        int classification = EasyScanner.nextInt();

        while(classification != 12 && classification != 15 && classification != 18)
        {

            System.out.print("Please enter a valid classification (12, 15, or 18) :");
            classification = EasyScanner.nextInt();

        }
        //take in the 3 values need to create and employee object

        System.out.print("Enter DVD running time (in minutes): ");
        int numMinutes = EasyScanner.nextInt();

        DVD dvd1 = new DVD(id, name, category, classification, numMinutes);  // creates an object called dvd1 of type DVD

        boolean ok;
        ok = dvdListIn.add(dvd1);             //calls the method add in DvdShop class and sends in object 
        //this method will return true if object was added successful
        //and false if object could not be added (because list was full)

        System.out.println();

        if(ok == false)   //(if(!ok)
        {
            System.out.println("Can not add new DVD. This list is full");
        }

        else
        {
            System.out.println("DVD Added");
        }

    }

    // remove DVD
    public static void option2 (DvdShop dvdListIn)
    {

        System.out.print("Enter DVD id to remove: ");
        String num = EasyScanner.nextString();

        // delete item if it exists
        boolean ok;
        ok = dvdListIn.remove(num);          //calls the method remove in DvdShop class and sends in string holding the employee number we want to delete 
        //this method will return true if object was delete successful
        //and false if object could not be deleted (because it was not there)

        if(ok == false)
        {
            System.out.println("Cannot delete DVD as no such DVD exist");
        }

        else
        {
            System.out.println("DVD with id number " +num+ " is removed");
        }

    }

    // check if empty
    public static void option3 (DvdShop dvdListIn)
    {

        if(dvdListIn.isEmpty()== true) 
        {
            System.out.println("The DVD Shop is empty");
        }

        else
        {
            System.out.println("The DVD Shop is not empty");
        }

    }

    // check if full
    public static void option4 (DvdShop dvdListIn)
    {

        if(dvdListIn.isFull() == true)      //if(dvdList.isFull() == true)
        { 
            System.out.println("The DVD Shop  is full");
        }

        else
        {
            System.out.println("The DVD Shop is not full");
        }

    }

    private static void option5(DvdShop dvdListIn)
    {

        //get employee number from user
        System.out.print("Enter DVD Id: ");
        String dvdId = EasyScanner.nextString();
        System.out.println();

        DVD dvd1 = dvdListIn.getItem(dvdId);  //checks for employeeNumber if it is there the method returns an object and stores it in employee
        if(dvd1 == null)                           // null indicates that it was not there
        {
            System.out.println("No such DVD Id exists");
        }

        else                                   // if employee number is found it asks the user to enter the additional details (frase and department)
        {
            System.out.print("Enter DVD Rating: ");
            int rating = EasyScanner.nextInt(); 

            System.out.println();

            boolean ok;
            ok = dvdListIn.addDetails(dvdId, rating);   //calls add details method and sends in the 3 variables required. 

            if(ok == false)
            {
                System.out.println("DVD details could not be updated"); 

            }   
            else
            {
                System.out.println("DVD details updated"); 
            }   
        }

    }

    // display list
    private static void option6(DvdShop dvdListIn)
    {

        {
            char choice2;

            System.out.println();
            System.out.println("Employee System");
            System.out.println("1. Add a DVD");
            System.out.println("2. Remove a DVD");
            System.out.println("3. Check if DVD Shop is Empty");
            System.out.println("4. Check if DVD Shop is Full");
            System.out.println("5. Add Additional DVD Details");
            System.out.println("6. DVD Details");
            System.out.println("\t a. Display Details of a DVD ");   //sub menu
            System.out.println("\t b. Display All DVD Details");
            System.out.println("\t c. Display Longest Running DVD ");
            System.out.println("\t d. Display Shortest Running DVD  ");             
            System.out.println("7. Update DVD Length of Time in Store ");
            System.out.println("8. Search DVD by Age Classification ");
            System.out.println("9. Exit System");
            

            System.out.print("Enter choice [a - d]: ");
            choice2 = EasyScanner.nextChar();
            System.out.println();

            // process menu options
            switch(choice2)
            {
                case 'a': 
                option6a(dvdListIn); 
                break;

                case 'b': 
                option6b(dvdListIn); 
                break;

                case 'c': 
                option6c(dvdListIn); 
                break;

                case 'd': 
                option6d(dvdListIn); 
                break;

                default : 
                System.out.println("Invalid entry, please enter a -d only");
                break;
            }
        }
    }

    private static void option6a(DvdShop dvdListIn)    
    {
        // get details from user
        System.out.print("Enter DVD id: ");
        String id = EasyScanner.nextString();

        DVD dvd1 = dvdListIn.getItem(id);       //checks for employeeNumber if it is there the method returns an emplplyee object and stores it in employee

        if (dvd1 == null)
        {
            System.out.println("No such DVD id exists");
        }

        else
        {
            System.out.println();
            System.out.println("DVD id: " + dvd1.getDvdId());    //calls attributes of the employee using methods in the DVD class
            System.out.println("DVD name: " + dvd1.getDvdName());
            System.out.println("DVD age clasification: " + dvd1.getAgeClassification());
            System.out.println("DVD category: " + dvd1.getCategory());
            System.out.println("DVD rating: " + dvd1.getRating());
            System.out.println("DVD running time: " + dvd1.getNumMinutes());
            System.out.println();
            System.out.println();
        }

    }

    private static void option6b(DvdShop dvdListIn)
    {

        String list = dvdListIn.list();       //calls the list method an empty string will  be return is no employees exist
        //if employees exist a string containing all the emplopyee details will be sent back

        if ( list.equals(""))
        {
            System.out.println("There are no DVDs in the shop");
        }

        else
        {
            System.out.println(list);
        }

    }

    private static void option6c(DvdShop dvdListIn)    
    {

        DVD temp =dvdListIn.checkLongestDvd();  // calls the checkOldestEmployee method and the oldest employees object will be returned

        if (temp == null)                          // null is returned if no employees exist
        {
            System.out.println("No DVD are added into the system");
        }

        else
        {
            System.out.println(temp.getDvdName()+ " with dvd id "
                + temp.getDvdId()+" is the longest running dvd (" 
                + temp.getNumMinutes() + " minutes )");
        }

    }

    private static void option6d(DvdShop dvdListIn)    
    {

        DVD temp =dvdListIn.checkShortestDvd();   // calls the checkYoungestEmployee method and the oldest employees object will be returned

        if (temp == null)                             // null is returned if no employees exist
        {
            System.out.println("No DVD are added into the system");
        }

        else
        {
            System.out.println(temp.getDvdName()+ " with dvd id "
                + temp.getDvdId()+" is the shortest running dvd (" 
                + temp.getNumMinutes() +  " minutes )");
        }      

    }

    private static void option7(DvdShop dvdListIn)
    {

        String info = dvdListIn.upDatelenOfTime();         //calls the method to update everyones years of service
        System.out.println(info);
    }
    
    public static void option8 (DvdShop dvdListIn)
    {
        System.out.print("Enter age classification of DVDs to view: ");
        int ageClassification = EasyScanner.nextInt();
        
        String result = dvdListIn.dvdByClassification(ageClassification);
        
        if ( result.equals(""))
        {
            System.out.println();
            System.out.println("There are no DVDs for the age classification "+ageClassification);
        }

        else
        {
            System.out.println("There DVDs for the age classification "+ageClassification+ " are as follows");
            System.out.println(result);
        }
        
    }

}
