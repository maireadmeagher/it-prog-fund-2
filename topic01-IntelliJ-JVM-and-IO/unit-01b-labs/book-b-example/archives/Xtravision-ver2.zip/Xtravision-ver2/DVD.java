/* This updated DVD class includes as extras from the original solution: 
 *  1. USe of this. structure
 *  2. Validation code for ageClassification and rating (constructor and setters)
 *  3. toString()
 */

public class DVD                                                                                                                                  
{

       private String dvdId;
       private String dvdName;
       private int ageClassification;   // should be between 12 and 18.
       private String category;
       private int numMinutes;
       private static int lenOfTime;
       private int rating;              // should be between 0 and 5
       
    
    
       // constructor to initialize 
       public DVD(String dvdId, String dvdName, String category, int ageClassification, int numMinutes)
       {
          this.dvdId = dvdId;
          this.dvdName = dvdName;
          this.category = category;
          if (ageClassification >= 12 && ageClassification <=18)
            this.ageClassification = ageClassification;
          else 
            this.ageClassification = 18;
          this.numMinutes = numMinutes;
          this.rating = 0;           //rating will be decided later
          this.lenOfTime = 0;     //lenOfTime will be changed later       
       }
    
       // set dvd id
       public void setDvdId(String dvdId )
       {
          this.dvdId = dvdId;
       }
    
    
      
       public String getDvdId()
       {
            return dvdId;
       }
       
        
       public void setDvdName(String dvdName)
       {
          this.dvdName = dvdName;
       }
    
    
          
        public String getDvdName()
          {
             return dvdName ;
    
        }
        
         
        public int getAgeClassification()
        {
             return ageClassification;
    
        }
        
          
        public void setAgeClassification(int ageClassification)
        {
            if (ageClassification >= 12 && ageClassification <= 18) 
                this.ageClassification = ageClassification;
            else this.ageClassification = 18;
    
        }
        
        
         
        public String getCategory()
        {
             return category;
    
        }
        
     
        public void setCategory(String category)
        {
             this.category = category;
    
        }
        
        
        public int getRating()
        {
             return rating;
    
        }
        

        public void setRating(int rating)
        {
            if  (rating >=0 && rating <=5)
             this.rating = rating;
            else
             this.rating = 0;
    
        }
            
        public int getNumMinutes()
        {
             return numMinutes;
    
        }
        

        public void setNumMinutes(int numMinutes)
        {
             this.numMinutes = numMinutes;
    
        }        
        
  
        public  static int getLenOfTime()
        {
            return lenOfTime;
        }
 
         public  static void setLenOfTime()
        {
                lenOfTime = lenOfTime + 1;
        }
        
        public String toString() {
            return ("DVD ID: " + dvdId  + "  Name : " + dvdName + 
                    "\nAgeClassification : " + ageClassification + 
                    "  Category : " + category + "  Rating : " + rating +
                    "\nLength of running time :" + numMinutes + 
                    "\nNumber of years in store: " + lenOfTime );
                }
 
    
} // end class DVD















































//End of program
